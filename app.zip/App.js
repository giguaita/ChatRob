import React, { useState } from 'react';
import { View, Text, Button, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

const App = () => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');

  const handleSend = () => {
    if (inputText.trim() === '') return;
    const newMessage = { text: inputText, sender: 'me' };
    const botResponse = generateBotResponse(inputText);
    setMessages([...messages, newMessage, botResponse]);
    setInputText('');
  };

  const generateBotResponse = (message) => {
    const trimmedMessage = message.trim().toLowerCase();

    if (trimmedMessage === 'oi') {
      return { text: 'Oi, como vai?', sender: 'bot' };
    } else if (trimmedMessage.includes('estou bem e voce?')) {
      return { text: 'Sim, estou bem! voce tomou água hoje?.', sender: 'bot' };
    } else if (trimmedMessage.includes('sim')) {
      return { text: 'Que ótimo! Água faz muito bem', sender: 'bot' };
    } else if (trimmedMessage.includes('nao')) {
      return { text: 'Que horror! Precisa tomar! Sabia que ela melhora muito sua pele e além de tudo sua saúde! Então me diga vai tomar água?', sender: 'bot' };
    } else if (trimmedMessage.includes('ok vou tomar agua')) {
      return { text: 'Muito bem, fico feliz por voce estar se cuidando! Mas bem preciso ir, foi ótimo conversar com voce, até mais!', sender: 'bot' };
    } else if (trimmedMessage.includes('tchau')) {
      return { text: 'Até mais!', sender: 'bot' };

    } else {
      return { text: 'Desculpe, não entendi. Pode repetir?', sender: 'bot' };
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.messagesContainer}>
        {messages.map((message, index) => (
          <View key={index} style={[styles.messageContainer, { alignSelf: message.sender === 'me' ? 'flex-end' : 'flex-start' }]}>
            <View style={[styles.messageBubble, { backgroundColor: message.sender === 'me' ? '#007AFF' : '#4CD964' }]}>
              <Text style={{ color: 'white' }}>{message.text}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Digite sua mensagem..."
          value={inputText}
          onChangeText={setInputText}
        />
        <TouchableOpacity style={styles.sendButton} onPress={handleSend}>
          <Text style={{ color: 'white' }}>Enviar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    justifyContent: 'flex-end',
  },
  messagesContainer: {
    flex: 1,
  },
  messageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    maxWidth: '80%', // Limitando a largura máxima do balão de mensagem
  },
  messageBubble: {
    padding: 10,
    borderRadius: 10,
    maxWidth: '100%', // Permitindo que o balão de mensagem ocupe a largura máxima
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderRadius: 20,
    marginRight: 10,
  },
  sendButton: {
    backgroundColor: '#4CD964',
    padding: 10,
    borderRadius: 20,
  },
});

export default App;
